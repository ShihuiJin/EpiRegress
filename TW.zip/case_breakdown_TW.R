#sort the number of local and imported cases in Taiwan
setwd(paste0('~/OneDrive - National University of Singapore/reimagine/data/TW'))
covid=read.csv('Confirmation_TW.csv')
date=unique(covid$date)
date[1]==paste0(22,'/',1,'/',2020)
m=c(0,31,29,31,30,31,30,31,31,30,31,30,31,31,28,31,30,31,30,31,31,30) #from Jan 1,2020 to Sept 30, 2021
m_cul=cumsum(m)
case=data.frame(date=rep(0,max(m_cul)),imported=rep(0,max(m_cul)),local=rep(0,max(m_cul)))
i=0;j=1
for(year in 2020:2021)
{
  for (month in 1:12)
  {
    if(year==2021&month==10) break
    for(day in 1:m[(year-2020)*12+month+1])
    {
      i=i+1
      case$date[i]=paste0(day,'/',month,'/',year)
      case$imported[i]=sum(covid$number[which(covid$date==case$date[i]&covid$imported==1)])
      case$local[i]=sum(covid$number[which(covid$date==case$date[i]&covid$imported==0)])
    }
  }
}
write.csv(case, 'case_TW.csv',row.names = FALSE)
